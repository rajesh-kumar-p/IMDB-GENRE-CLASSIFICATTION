TASK-1:
Retrieve top rated films based on its IMDB rating:

Problem Statement::

Our aim in this project is to explore the movie dataset and find some movies with high ratings. 
analyze a movie dataset  and explore the ratings of the movies. 
In our dataset, we have the details of the movies in more than 50 languages, 
but your friend is interested only in watching English movies. Thus, 
our goal is to analyze the data and suggest English movies with high-ratings.

Steps::

Different functions that you would require to define for this project has been mentioned. 
All the parameters and the task a function would do, has been mentioned here.

The data file has already been loaded for you and stored as a list in movies

The first row is the header. Extract and store it in movies_header Subset the movies dataset such that the header is 
removed from the list and store it back in movies Delete the wrong data. You will see that as apart from the id, 
description, status and title, no other information is available. Hence drop this row. 
Using explore_data() with appropriate parameters, view the details of the first 5 movies. 
Our dataset might have more than one entry for a movie. Call duplicate_and_unique_movies() 
with index of the name to check the same. We saw that there are 3 movies for which there are multiple entries.
Create a dictionary, reviews_max that will have the name of the movie as key, and the maximum number of reviews as values. 
Create a list movies_clean, which will filter out duplicate movies and contain the rows with the maximum number of reviews for duplicate movies, 
as stored in 'review_max'. Calling movies_lang(), extract all the English movies and store it in movies_en. 
Call the rate_bucket function to see the movies with a rating higher than 8 and store the resulting list in high_rated_movies.

output:
Examples of Movies in required rating bucket:
['185000000', "['Drama', 'Action', 'Crime', 'Thriller']", '155', 'en', 'Batman raises the stakes in his war on crime. 
With the help of Lt. Jim Gordon and District Attorney Harvey Dent, Batman sets out to dismantle the remaining criminal 
organizations that plague the streets. The partnership proves to be effective, but they soon find themselves prey to a 
reign of chaos unleashed by a rising criminal mastermind known to the terrified citizens of Gotham as the Joker.', '187.322927', 
"['United Kingdom', 'United States of America']", '2008-07-16', '1004558444', '152.0', 'Released', '8.2', '12002', 'The Dark Knight', 'Christopher Nolan']


['175000000', "['Drama', 'Comedy', 'Animation', 'Family']", '150540', 'en', "Growing up can be a bumpy road, 
and it's no exception for Riley, who is uprooted from her Midwest life when her father starts a new job in San Francisco. 
Like all of us, Riley is guided by her emotions - Joy, Fear, Anger, Disgust and Sadness. The emotions live in Headquarters, 
the control center inside Riley's mind, where they help advise her through everyday life. As Riley and her emotions struggle to 
adjust to a new life in San Francisco, turmoil ensues in Headquarters. Although Joy, Riley's main and most important emotion,
 tries to keep things positive, the emotions conflict on how best to navigate a new city, house and school.", '128.65596399999998', 
"['United States of America']", '2015-06-09', '857611174', '94.0', 'Released', '8.0', '6560', 'Inside Out', 'Pete Docter']

['165000000', "['Adventure', 'Drama', 'Science Fiction']", '157336', 'en', 'Interstellar chronicles the adventures 
of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and 
conquer the vast distances involved in an interstellar voyage.', '724.247784', "['Canada', 'United States of America', 'United Kingdom']", 
'2014-11-05', '675120017', '169.0', 'Released', '8.1', '10867', 'Interstellar', 'Christopher Nolan']
Number of rows: 76
Number of columns: 15

---------------------------------------------------------------------------------------------------------------------------------------------

TASK_2:
search a movie and its director.

Problem Statement::

Based on the data avialable from IMDB Dataset we find out the text search and also the Best Director of all times by using Facebook Like,IMDB Score and Average Revenue

STEPS::

The data file has already been loaded for you and stored as a list in movies

firstly we are processing the data, removing the stopwords,creating the inverted index,
process the quesry as vector and finally based on tf-idf score you can get the result of your query.

I am just calculating the intersection between the Facebook Like, IMDB Score and Average Revenue.
after that sorting the index gives you the ascending order of faceook likes provided to each film. Now I am eliminating the
null values i.e zeo facebook likes because there is no use of the null values.
now I am intersecting this facebook likes with imdb score and number of critic reviews.
so that based on this we can calculate the best director. similarly you do the same process for finding the movie also.

Based on the analysis done by comparing all the facebook likes which shows how popular a director is among masses,
How much successful he is in terms of revenue generated and imdb score which evolves with time we come to the conclusion 
that Christopher Nolan is the best director and The Dark Knight is the best movie.
Text Search:
I am doing a Movie Search Engine. So, on the server, a user can enter few keywords and from that keywords, we would rank what all movie are relevant to that free text.

How do we do that:
Preprocess our csv file. Tokenize the plot, converting our plot to the lower case, remove stop words. Create an inverted index.
Build our document vector in which we calculate our TF-IDF scores.
We then process our query or keywords that the user had entered and calculate total tf-idf score, idf score for individual query term and tf score for individual query term.
At last we print title, plot, tf-idf score, idf score, tf score and IMDB rating.

Keyword: Kid alone at home
output:
Without tf-idf normalization:

('Home Alone: Purged', "There's something of value in an old family home. A group of scavengers gather to take it. Left home alone, 3 kids must try to stop them.", 3.800885136649116, nan)

('Kids vs. Zombies', 'A young brother and sister work together to outwit a barrage of peculiar zombies, rescue their mom and save the town. Action-packed, gut-busting zombie fun for all ages. "Home Alone" meets "Zombieland".', 3.110899569636624, nan)

('The Gate', 'Kids, left home alone, accidentally unleashes a horde of malevolent, pint-sized demons from a mysterious hole in their suburban backyard.', 3.110899569636624, 6.0)

('Home Alone Horror', 'A boy left home alone realizes he may not be totally alone.', 2.7523199410205397, 6.6)

('Alone', "Erin is spending her first night home alone in many years. Even though she's locked safely inside, every bump, every creak, every little sound convinces her she is not alone.", 2.5690183438974192, nan)

With tf-idf normalization:

('A Girl Walks Home Alone at Night', 'A girl walks home alone at night and a man starts to follow her.', 0.45904343187331254, 6.5)

('Alone', 'A man who is stuck alone in his home and is being haunted by his dead wife.', 0.4571230787656072, nan)

('Home', 'Home is where you are.', 0.4424205006970245, nan)

('Home Alone Horror', 'A boy left home alone realizes he may not be totally alone.', 0.4412866356710031, 6.6)

('Home Alone: Purged', "There's something of value in an old family home. A group of scavengers gather to take it. Left home alone, 3 kids must try to stop them.", 0.4083518533240615, nan)

Lemmatization:

('Alone', 'A man who is stuck alone in his home and is being haunted by his dead wife.', 0.4432479421067452, nan).

('Home', 'Home is where you are.', 0.4358973946078705, nan).

('Home Alone Horror', 'A boy left home alone realizes he may not be totally alone.', 0.4139130726129726, 6.6).

('Home Alone: Purged', "There's something of value in an old family home. A group of scavengers gather to take it. Left home alone, 3 kids must try to stop them.", 0.39285220213737304, nan).

('A Girl Walks Home Alone at Night', 'A girl walks home alone at night and a man starts to follow her.', 0.3754790320456582, 6.5).










